package com.mvc;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/RegController")
public class RegController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public RegController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String mob = request.getParameter("mob");
        String dob = request.getParameter("dob");
        String[] course = request.getParameterValues("course");

        String c = "";
        if (course != null) {
            for (int i = 0; i < course.length; i++) {
                c = c + course[i] + " ";
            }
        }

        String gender = request.getParameter("gender");
        String address = request.getParameter("address");
        String country = request.getParameter("country");

        String region = request.getParameter("region");
        String pinst = request.getParameter("pin");
        int pin = 0;

        try {
            pin = Integer.parseInt(pinst);
        } catch (NumberFormatException e) {
            // Handle the case where 'pin' is not a valid integer
            e.printStackTrace();
        }

        RegModel rm = new RegModel();

        rm.setName(name);
        rm.setEmail(email);
        rm.setPassword(password);
        rm.setMob(mob);
        rm.setDob(dob);
        rm.setCourse(c);
        rm.setGender(gender);
        rm.setAddress(address);
        rm.setCountry(country);

        rm.setRegion(region);
        rm.setPin(pin);

        int status = MainDao.save(rm);

        if (status > 0) {
            HttpSession session = request.getSession();
            session.setAttribute("sesreg", "success");
            response.sendRedirect("login.jsp");
        }
    }
}
